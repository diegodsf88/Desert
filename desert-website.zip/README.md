# Desert Vibes Website 🌵

Simple static website with a desert theme.

## Features
- Responsive layout
- Clean design
- Easy to customize

## How to Run
Just open `index.html` in your browser.

## Author
Created for GitHub portfolio.
